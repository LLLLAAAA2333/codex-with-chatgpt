#!/usr/bin/env node
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

// Local skill installation only. No dependency installation or network access.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const source = path.join(root, "skill");
const codexHome = process.env.CODEX_HOME?.trim() || path.join(os.homedir(), ".codex");
const target = path.resolve(codexHome, "skills", "codex-with-chatgpt");
const template = fs.readFileSync(path.join(source, "SKILL.md"), "utf8");
if (!template.includes("<ACTUAL_CHECKOUT_PATH>")) {
  throw new Error("Skill checkout placeholder is missing; installation stopped.");
}
fs.mkdirSync(path.dirname(target), { recursive: true });
try {
  fs.mkdirSync(target);
} catch (error) {
  if (error.code === "EEXIST") {
    console.error(`Skill already exists: ${target}\nInstallation stopped without overwriting it. Back it up and move it before retrying.`);
    process.exit(1);
  }
  throw error;
}
try {
  fs.cpSync(source, target, { recursive: true, force: false, errorOnExist: true });
  fs.writeFileSync(path.join(target, "SKILL.md"), template.replaceAll("<ACTUAL_CHECKOUT_PATH>", root));
} catch (error) {
  fs.rmSync(target, { recursive: true, force: true });
  throw error;
}
console.log(`Installed skill: ${target}\nKeep this project folder at: ${root}\nNo connection or authorization was started.`);
